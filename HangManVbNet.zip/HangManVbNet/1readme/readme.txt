-----------------------------------------------------------------
 HangMan V1.0 - VbGames.com
-----------------------------------------------------------------

Copy the hm.ini file from the root folder (C:\hangmanvbnet\) to the bin folder (C:\hangmanvbnet\bin\)

If you get the following message:

"A file is missing or corrupted!"

1. Copy the hm.ini file from the root folder (C:\hangmanvbnet\) to the bin folder (C:\hangmanvbnet\bin\)
2. Delete the values.dat file from the bin folder (C:\hangmanvbnet\bin\)

-----------------------------------------------------------------

 Questions contact us at http://www.VbGames.com

 Email: devteam@vbgames.com

------------------------------------------------------------------------
